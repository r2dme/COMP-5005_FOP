#
# hello.py: Print out greetings in various languages
#

print ('Hello')
print ("G'Day")
print ('Bula')
print("Kia ora")


