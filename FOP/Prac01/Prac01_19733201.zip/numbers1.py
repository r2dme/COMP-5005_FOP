#
# number1.py: Read in number and echo the number 
#             and its type to screen:

print ('Enter a number...')
numberstr = input()
print ('Number =', numberstr, 'Type: ', str(type(numberstr)))

number = int(numberstr)
print ('Number =',number, ' Type :', str(type(numberstr)))


